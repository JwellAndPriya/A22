﻿// DefaultX.cpp : Defines the entry point for the application.
//

#include "DefaultX.h"

using namespace std;

int main()
{
	cout << "Hello CMake." << endl;
	return 0;
}
